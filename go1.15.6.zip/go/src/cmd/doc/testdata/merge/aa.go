// Package comment A.
package merge

// A doc.
func A() {
	// A comment.
}
